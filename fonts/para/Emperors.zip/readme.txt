Emperor's Scrawl - (C) 1998 Letters From The Claw

Now you can forge The Claw's own fiendish handwriting and release Imperial Orders with all the power, majesty, and authority of The Claw himself.

The little drawings inserted for the [ and ] keys are Jack and Bert, respectively, two characters from The Claw's ongoing comic strip "Tales Of The Illuminati".  (Visible at http://www.mysite.com/empire) Now you, too can tell funny stories about the secret cabal that really rules the world!

This font is freeware.  Distribute freely, but keep this file with it. Think about it, won't you?  Thank you.

---
The Claw
theclaw@hypercon.com
http://www.mysite.com/empire


