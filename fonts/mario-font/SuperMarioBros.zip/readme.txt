Thanks for downloading my fonts!

... More Fonts ..........................
Get all of my fonts now, and come back
for another one, free each month!
http://www3.sk.sympatico.ca/wilsdd/fonts/
Find all the best fonts on the Internet
with high speed downloads at:
http://web23.interspeed.net/fonts/

... Chlorine ............................
Visit Chlorine for more original fonts,
swimming info, and lots of cool stuff.
http://loosefoot.com/chlorine/

... Freeware Info .......................
You are free to use my fonts as much
as you like, please email me, I'd like
to see what you've done with it!
To redistribute Chlorinov, please send
an email to chlorine@bigfoot.com for my
permission. Thanks.

   __      __  ____  ____  ____  ____ __  
  / /     / / / __/ / __/ / __/ / __/ \ \ 
 ( (   __/ / / __/ _\ \  _\ \  / __/   ) )
  \_\ /___/ /___/ /___/ /___/ /___/   /_/ 
                                          
####### www.loosefoot.com/chlorine #######
#######    chlorine@bigfoot.com    #�1998#

